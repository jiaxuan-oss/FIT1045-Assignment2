#Author(s): Yew Jin Ruo, Teh Jia Xuan, Tan Jian Hao, Isha Maumoon
#Team: Musang King
#Date Edited: 2/1/2023

import time
import math
import random

#please upload all files from Task 1 to 6 to run codes
from property import Property
from property_generator import PropertyGenerator
from property_csv_data_a import csv_data
csv_data_a = csv_data
from property_csv_data_b import csv_data
csv_data_b = csv_data
from player import Player
from player_move import PerpendicularPlayer, DiagonalPlayer, LPlayer
from ai_player import AIPlayer

class PyPoly:
    #add methods
    """
    Runs PyPoly game when PyPoly object is created.
         
    Class variables:
    ALL_PLAYERS - list to store all non-AI player objects inside
    AI_PLAYERS - list to store all AI player objects inside

    Instance variables of PyPoly:
    delimeter: store delimeter of csv_data file used(String)
    row_of_board: row of the board when play eg (6x6,5x5) (int)
    winning_condition: number of property and at least one hotel on each property needed to win
    """

    #Instantiating class variables
    ALL_PLAYERS = []
    AI_PLAYERS = []

    #constructor (no input arguments)
    def __init__(self):
        #instance variables
        #self.delimiter - used to store the delimiter of the csv data file used (String)
        #self.row_of_board - used to store the number of rows of the chosen board
        self.delimiter = ""
        self.row_of_board = 0
        self.winning_condition = 0

        #print welcome message
        self.print_welcome_msg()
        time.sleep(0.5)

        #get number of AI and non-AI players, properties needed to win from user input, and create instances of each player
        number_of_players = self.number_of_players()                    #get number of players from user input
        time.sleep(0.5)
        total_AI_players = self.choose_AI_or_non_AI(number_of_players)  #get total AI player from user input
        time.sleep(0.5)
        winning_condition = self.set_winning_condition()                #set number of properties and at least one hotel needed at every properties needed to win
        time.sleep(0.5)
        self.set_properties_player(number_of_players, total_AI_players) #set properties of players (eg.MOVE_TRAIT) and create object for player

        #choose board A or B and randomly generate property locations and chance grid locations
        chosen_board = self.choose_board()                              #get board to use by user
        time.sleep(0.5)
        all_properties = PropertyGenerator()                            #create PropertyGenerator object to generate property
        all_properties.csv_to_properties(chosen_board, self.delimiter)  #generate properties by using chosen board and delimeter
        all_properties.property_location_generator()                    #generate all location for properties within the board chosen (eg 5x5, 6x6)

        #set initial locations of each player
        self.set_initial_locations()                                    #randomly set initial location for players and AI(if there is any)
        #set symbols of each player
        self.set_symbols()                                              #set symbol for player(eg 1,2,3) and AI(eg. a,b,c)
        #start gameplay #unfinished
        
        self.play_turns(all_properties.property_locations, self.row_of_board)   #start the game after everything is ready


    def get_row_of_board(self)->int:
        """
        Returns row of board

        Arguments:
        - None

        Returns:
        - self.row_of_board(int): integer representing row of board
        """
        return self.row_of_board
    
    def print_welcome_msg(self)->None:
        """
        Prints welcome message when game starts.

        Arguments:
        -None

        Returns:
        -None
        """
        print("Welcome to \U0001F4B0 PyPoly \U0001F4B0") 
        print()

    def number_of_players(self)->int:
        """
        Returns the number of players

        Arguments:
        - None

        Returns:
        - number_of_players(int) - integer representing number of players
        """

        number_of_players = int(input("How many players do you want?: "))   #ask user to input number of player
        print()

        while number_of_players >= 6 or number_of_players < 2:              #jump in loop and ask again if it is inappropriate 
            print("Number of players must be between 2 to 6.")              #output 
            time.sleep(0.3)
            number_of_players = int(input("How many players do you want?: "))#ask again until it gets appropriate input
            print()
            
        return number_of_players                                            #return number_of_players
        
    def choose_AI_or_non_AI(self, number_of_players:int)->int:
        """
        1 for AI 2 for non AI
        returns total number of AI Players

        Arguments:
        -number_of_players(int): integer representing number of players

        Return
        -total_AI_players(int): integer representing number of AI
        """
        print("Do you want to play against\n[1] AI players  or\n[2] Regular players?")
        choose_AI = int(input("")) #ask player to choose whether AI or player
        print()

        while (choose_AI != 1) and (choose_AI != 2):                #jump in loop if inappropriate value
            print("Please choose from the given options above.")    #print requirement
            time.sleep(0.3)                                        #ask again until appropriate value
            choose_AI = int(input("Do you want to play against\n[1] AI players or\n[2] Regular players?\n"))
        
        if choose_AI == 1:                                          #if player choose AI
            total_AI_players = int(input("How many AI players do you want? "))   #ask how many AI he wants
            print()

            while total_AI_players > number_of_players or total_AI_players < 1: #if inappropriate input then jump in loop
                print("Number of AI players cannot exceed the number of players or less one") #print requirement
                time.sleep(0.3)
                total_AI_players = int(input("How many AI players do you want?"))   #ask for input until appropriate value 
                print()
        else:
            total_AI_players = 0    #if player choose regular player then total_AI_players = 0

        return total_AI_players     #return total_AI_players
    
    #setters to modify the values of instance
    def set_winning_condition(self)->int:
        """
        set number of properties and each properties need at least 1 hotel needed to win 

        Arguments:
        - None

        Returns:
        - self.winning_condition(int): integer representing number of properties needed to win
        """
        time.sleep(0.5)
        self.winning_condition = int(input("What is the number of properties needed to win? ")) #ask user to input winning condition
        print()

        while self.winning_condition >= 5 or self.winning_condition < 1:        #if inappropriate value received jump in loop
            print("Number of properties needed to win must be between 1 to 5.") #state the error
            time.sleep(0.3)
            self.winning_condition = int(input("What is the number of properties needed to win? ")) #ask for input again until appropriate value is received
            
        return self.winning_condition   #return winning_condition
        
    def set_properties_player(self, number_of_players:int, total_AI_players:int)-> None:
        """
        set player and AI's properties eg(name, move_trait)

        Arguments:
        - number_of_players(int) - integer representing number of players
        - total_AI_players(int) - integer representing number of AI_PLAYERS

        Returns:
        - None
        """

        condition = number_of_players - total_AI_players        #get total regular player
        for index in range(condition):                          #if there is regular player then loop through
            flag = True                             
            player_name = input("What is player {}'s name? ".format(index+1)) #ask for input player's name
            time.sleep(0.5)
            print()
            player_obj = ""
            print("What is {}'s move trait? ".format(player_name))  #ask for player's move_trait
            time.sleep(0.5)
            
            while flag == True:
                move_trait = int(input("[0] Perpendicular [1] Diagonal [2] L: ")) #store move_trait
                print()
                    
                if move_trait == 0:     #if it is 0
                    player_obj = PerpendicularPlayer()  #then create player object from PerpendicularPlayer and move_trait
                    player_obj.set_name(player_name)    #set name for that player
                    self.ALL_PLAYERS.append(player_obj) #store player object to ALL_PLAYERS
                    flag = False                        #jump out loop

                elif move_trait == 1:                   #if is 1
                    player_obj = DiagonalPlayer()       #then create player object from DiagonalPlayer and move_trait
                    player_obj.set_name(player_name)    #set name for that player
                    self.ALL_PLAYERS.append(player_obj) #store player object to ALL_PLAYERS
                    flag = False                        #jump out loop

                elif move_trait == 2:                   #if is 2
                    player_obj = LPlayer()              #create player object from LPlayer() and move_trait
                    player_obj.set_name(player_name)    #set name for that player
                    self.ALL_PLAYERS.append(player_obj) #store player object to ALL_PLAYERS
                    flag = False                        #jump out loop

                else:                                   #if values inappropriate then ask again 
                    print("Please enter number within 0 to 2 to indicate your move trait. ")

        for index in range(total_AI_players):           #create object for AI_player
            player_name = "ROBOT {}".format(index+1)    #output name
            player_obj = AIPlayer()                     #create object
            player_obj.set_name(player_name)            #set AI name
            self.AI_PLAYERS.append(player_obj)          #add AI to the list
            

    #ask player to choose board
    def choose_board(self)-> list:
        """
        ask player to choose board 

        Arguments:
        - None

        Returns:
        - file_name(list): list representing all the properties details
        """
        board_chosen = input("Which board do you want?:\n[A]Monopoly Avenue [B]Monopoly City ") #ask which board to use
        print()

        while board_chosen !="A" and board_chosen != "B":   #loop through if inappropriate value
            print("I am sorry, only board A and B available for now <3 ")   #print error
            time.sleep(0.3)
            board_chosen = input("Which board do you want?:\n[A]Monopoly Avenue [B]Monopoly City ") #ask again until appropriate value
            print()
            
        if board_chosen == "A": #if is board A 
            file_name = csv_data_a #use csv_data_a 
            self.delimiter = "/"    #set delimeter 
            self.row_of_board = 5   #set row of board to 5

        elif board_chosen == "B":   #if is board B
            file_name = csv_data_b  #use csv_data_b
            self.delimiter = "|"    #set delimeter
            self.row_of_board = 6   #set row of board to 6

        return file_name            #return file_name

    def random_set_location(self, row_size: int, player: object)-> None:
        """
        Randomly sets initial locations for a specific player.

        Arguments:
        - row_size: Integer representing the row size of the board
        - player: Object of subclasses of Player class

        Returns:
        - None
        """
        #randomly generate a location for the player at the start of the game
        x = random.randint(0, row_size - 1)
        y = random.randint(0, row_size - 1)
        
        #set the location of that player in its position instance variable
        player.set_position((x,y))

    def set_initial_locations(self):
        """
        Randomly sets initial locations for all AI and non-AI players.
        
        Arguments:
        - None
        
        Returns:
        - None
        """
        #get initial locations for every player
        for player in range(len(self.ALL_PLAYERS)):                                 #loop through player list
            self.random_set_location(self.row_of_board, self.ALL_PLAYERS[player])   #set random location 

        for AI in range(len(self.AI_PLAYERS)):                                      #loop through AI player list
            self.random_set_location(self.row_of_board, self.AI_PLAYERS[AI])        #set random location

    def display_location(self, player: object)-> None:
        """
        Display initial locations of each AI and non-AI player for each round.

        Arguments:
        - player: Object of subclasses of Player class
        
        Returns:
        - None
        """
        #if the player's symbol is a digit, it is a non-AI player
        if (player.get_symbol().isdigit()):
            time.sleep(0.5)
            print("Player {} is currently at location {}".format(player.get_name(),player.get_position()))  #print to inform player its current location
        #if the player's symbol is not a digit, it is an AI player (print in different format)
        else:
            time.sleep(0.5)
            print("{} is currently at location {}".format(player.get_name(),player.get_position()))
        
        #display the position of the player on the board
        player.display_moves(self.row_of_board, True)

    def pick_valid_move_player(self, valid_moves: list[tuple], player: object)->tuple:
        """
        Ask user to input valid move based on the list given.
        
        Arguments:
        - valid_move(list[tuple]): list of tuple representing where player can go 
        -player(object): object representing which player playing this move
        
        Returns:
        - position(tuple): tuple representing movement chosen by player
        """
        self.display_location(player)           #display current location player

        print("Pick one valid move.")           #print to let user know where he/she can go 
        for index in range(len(valid_moves)):   #loop through the list where he/she can go
            print("[{}] - {}".format(index,valid_moves[index])) #print out
            time.sleep(0.1)

        move = int(input())                     #ask user to input where he/she goes

        while move > (len(valid_moves)-1) or move < 0: #if inappropriate value received
            print("Invalid move.")                     #print error
            time.sleep(0.3)
            move = int(input("Please choose again: ")) #can ask for input until appropriate value received
        
        position = valid_moves[move]                   #store location that player chose to position variable
        player.set_position(position)                  #set player position 

        return position                                #return that position

    def pick_valid_move_AI(self, row_size: int, property_locations: dict , player: object) -> tuple:
        """
        Pick a valid move automatically for AI player.

        Arguments:
        - row_size: Integer representing the row size of the board
        - property_locations: Dictionary that contains all the position-property key-value pairs
        
        Returns:
        - position: Tuple representing the move chosen by AI player
        """
        #call display location method to display initial location of the AI player
        self.display_location(player)
        
        #get the valid moves of the AI player using determine_valid_moves
        valid_moves = player.determine_valid_moves(row_size)
        
        #print all valid moves of the player
        print("Pick one valid move:")
        for index in range(len(valid_moves)):
            print("[{}] - {}".format(index,valid_moves[index]))
            time.sleep(0.1)
        
        #get the best move of the AI player using ai_move method
        most_valuable_move = player.ai_move(valid_moves, property_locations) 
        
        #set the AI player's position to the coordinates of the best move
        position = valid_moves[valid_moves.index(most_valuable_move)]
        player.set_position(position)
        time.sleep(1)
        
        #print the move chosen by the AI player to the screen
        print(valid_moves.index(most_valuable_move))
        
        #return the move chosen by the AI player
        return position

    def actions_option_player(self, player: object, property_locations: dict, row_size:int)-> object:
        """
        Outputs non-AI player's location and actions after player chooses a valid location, and lets the player to choose options until player
        chooses to go to next player/quit game.
        
        Arguments:
        - player: Object representing which player is playing 
        - property_location: Dictionary that contains all the position-property key-value pairs
        - row_size: Integer representing row size of the board

        Returns:
        - remove_player: Object representing the player that wants to quit the game (if any)
        """
        #flag - indicates if player has already finished choosing actions and is ready to pass the turn to the next player.
        #counter - only can be 2 int values, 0 or 1, 0 indicates that player has not built hotels or purchased properties, 1 indicates that player has built hotels or purchased properties
        flag = False
        check_chance = False
        counter = 0
        reward = 0
        fine = 0
        remove_player = None
        line = "*"*15

        print()
        print("Player {} moved to {}".format(player.get_name(), player.get_position())) #print player position
        time.sleep(0.5)
        player.display_moves(row_size, False)                                           #print board without display move

        player.determine_action(property_locations)                                     #determine where player lands and what action can player do 

        #if current property is penalty or rewards then only able to do movement 3,4,5
        if property_locations.get(player.get_position()).get_property_cost() == None or (property_locations.get(player.get_position()).get_owner() != Property.ORIGINAL_OWNER and property_locations.get(player.get_position()).get_owner() != player):
            action = int(input("[3] Sell Property [4] Next Player [5] Quit Game: "))    #ask for which movement does he/she like to do
            while (action < 3) or (action > 5):                                         #if invalid move then enter loop 
                print("Please input a valid option number.")                            #print error
                time.sleep(0.3)
                action = int(input("[3] Sell Property [4] Next Player [5] Quit Game: "))#and ask again until valid

            if action == 3:                                                             #if 3(sell_property) is chosen
                if (len(player.get_properties_owned())) > 0:                            #check whether player owns any property, if yes
                    print("These are the properties owned by {}.".format(player.get_name())) #output it
                    time.sleep(0.1)
                    for index in range(len(player.get_properties_owned())):                  #loop through the properties he owned
                        print("[{}]- {}".format(index, player.get_properties_owned[index]))  #output
                        time.sleep(0.1)
            
                    property_chosen = int(input("Which property would you like to sell? "))  #ask for which property wants to be sold
                    while property_chosen > len(player.get_properties_owned()) and property_chosen <0:#if answer not within the range 
                        print("Invalid move, Please choose a property within the range.")             #raise error until it is 
                        time.sleep(0.3)
                        property_chosen = int(input("Which property would you like to sell? "))       #correct

                    player.sell_property(player.get_properties_owned[property_chosen])      #if everything is correct and accurate
                                                                                            #then sell property that player chosen
                                                                                            
                else:                                                                       #if player doesn't own any properties 
                    print("You have no property to sell.")                                  #output no property to sell

            elif action == 4:                                                               #if action 4(next player) is chosen
                #sets flag to True to jump out of while loop if next player is chosen.
                flag = True                                 

            elif action == 5:                                                               #if action 5(quit game) is chosen
                #save the player that wants to quit in a list (will remove when round ends)
                remove_player = player
                print("{} has left the game.".format(player.get_name()))
                time.sleep(0.5)
                flag = True                                                                 #flag = True jump out the loop

        else:   #if landed on property 
            while flag == False:  
                print("Pick a choice: ")
                time.sleep(0.3)
                #counter - only can be 2 int values, 0 or 1, 0 indicates that player has not built hotels or purchased properties, 1 indicates that player has built hotels or purchased properties
                if counter == 0:    #if is 0 then can do 1,2,3,4,5
                    action = int(input("[1] Purchase property [2] Purchase hotel [3] Sell Property [4] Next Player [5] Quit Game: "))
                    while (action < 1) or (action > 5):             #if inappropriate value loop until player give appropriate value
                        print("Please input a valid option number.")#print error
                        time.sleep(0.3)
                        #ask again
                        action = int(input("[1] Purchase property [2] Purchase hotel [3] Sell Property [4] Next Player [5] Quit Game: "))
                else:   #if counter = 1, player only can do 3,4,5
                    action = int(input("[3] Sell Property [4] Next Player [5] Quit Game: "))
                    while (action < 3) or (action > 5):#if inappropriate value loop until player give appropriate value
                        print("Please input a valid option number.")#print error
                        time.sleep(0.3)
                        action = int(input("[3] Sell Property [4] Next Player [5] Quit Game: ")) # ask again until appropriate

                #if 1(purchase_property) and current location owner not bank 
                if action == 1 and property_locations.get(player.get_position()).get_owner() == Property.ORIGINAL_OWNER:
                        player.purchase_property(property_locations.get(player.get_position())) #player able to purchase
                        counter += 1    #add one to counter

                elif action == 2: #if 2(purchase hotel) 
                    player.purchase_hotel(property_locations.get(player.get_position())) #purchase hotel
                    counter += 1 #plus 1

                elif action == 3: #if 3(sell_property)
                    if (len(player.get_properties_owned())) > 0: #check is there any property owned, if yes
                        print("These are the properties owned by {}.".format(player.get_name())) #output it 
                        time.sleep(0.3)
                        for index in range(len(player.get_properties_owned())): #loop through the property he owned
                            print("[{}]- {}".format(index, (player.get_properties_owned())[index])) #output
                            time.sleep(0.1)
                        time.sleep(0.5)
            
                        property_chosen = int(input("Which property would you like to sell? ")) #ask for which property player wants to sell

                        #if inappropriate value then loop until appropriate
                        while property_chosen > len(player.get_properties_owned()) and property_chosen <0: 
                            print("Invalid move, Please choose a property within the range") #print error
                            time.sleep(0.5)
                            property_chosen = int(input("Which property would you like to sell? ")) #ask again

                        player.sell_property((player.get_properties_owned())[property_chosen]) #player able to sell if player enters appropriate value

                    else:
                        print("You have no property to sell.")  #if player doesn't owned any property then print error msg
                        time.sleep(0.5)

                elif action == 4: #if 4 (next player)
                    #sets flag to True to jump out of while loop if next player is chosen.
                    flag = True

                elif action == 5:#if 5 (quit game)
                    #save the player that wants to quit in a list (will remove when round ends)
                    remove_player = player
                    print("{} has left the game.".format(player.get_name())) #output statement
                    time.sleep(0.5)
                    flag = True #jump out loop

        print()
        print(line)
        print()
        player.display_player_properties() #display state of player (total property and hotel) of player
        time.sleep(0.5)
        print()
        print("Player {} has ${} left.".format(player.get_name(), int(player.get_fund()))) #print player's current fund
        time.sleep(0.5)
        print()
        print(line)
        print()

        return remove_player #return remove_player

    def actions_option_AI(self, player: object, property_locations: dict)-> None:
        """
        Outputs AI player's location (after movement) and do actions automatically until the next player's turn.

        Arguments:
        - player: object of class AIPlayer
        - property_locations: Dictionary that contains all the position-property key-value pairs

        Returns:
        - None
        """
        #line used when printing the AI player's properties
        line = "*"*15

        print()
        #print the position where the AI player chose to move to
        print("{} moved to {}".format(player.get_name(), player.get_position()))
        time.sleep(0.5)
        #display the board without valid moves being printed
        player.display_moves(self.row_of_board, False)

        #call AIPlayer's buy_or_build function to let AI make decisions automatically
        time.sleep(1)
        player.buy_or_build(player.get_position(), property_locations)
        time.sleep(1)


        print()
        print(line)
        print()
        player.display_player_properties() #call display_player_properties to display the AIPlayer's properties
        time.sleep(1)
        print()
        print("{} has ${} left.".format(player.get_name(), int(player.get_fund()))) #display how much money the AI player has left
        time.sleep(1)
        print()
        print(line)
        print()

    def set_symbols(self)-> None:
        """
        Set the symbols of each AI and non-AI player before gameplay starts.

        Arguments:
        - None

        Returns:
        - None
        """
        #ASCII code for lowercase letters start from 97
        AI_symbol = 97

        #for each non-AI player, set their symbol as their player digit eg. player 1 -> symbol = 1
        for player in range(len(self.ALL_PLAYERS)):                       #loop through all non-AI players
            self.ALL_PLAYERS[player].set_symbol(str(player+1))            #set their symbol to their player digit

        #for each AI player, set their symbol as lowercase letters starting from 'a'
        for AI in range(len(self.AI_PLAYERS)):                            #loop through all AI players
            self.AI_PLAYERS[AI].set_symbol(chr(AI_symbol))                #set the symbol to the ASCII character with the AI_symbol value
            AI_symbol += 1                                                #add 1 to the AI_symbol value after the symbol has been used

    def play(self, player:object, property_locations:dict, row_size:int)-> object:
        """
        Runs one turn of a specific non-AI player.

        Arguments:
        - player: Object of subclasses of Player class (representing the current player)
        - property_locations: Dictionary that contains all the position-property key-value pairs
        - row_size: Integer representing row size of the board

        Returns:
        - remove_player: Object representing the player that wants to quit the game (if any)
        """
        #get the valid moves of the non-AI player
        valid_moves = player.determine_valid_moves(row_size)
        #call pick_valid_move_player to let player choose a valid move
        self.pick_valid_move_player(valid_moves, player)
        #call actions_option_player to continue to let the player choose their actions and return the player that wants to quit the game (if any)
        remove_player = self.actions_option_player(player, property_locations, row_size)
        
        #return the player that wants to quit the game (if any), if no, returns None
        return remove_player

    def play_AI(self, player:object, property_locations: dict, row_size: int)-> None:
        """
        Runs one turn of a specific AI player.
        
        Arguments:
        - player: Object of AIPlayer class (representing the current AI player)
        - property_locations: Dictionary that contains all the position-property key-value pairs
        - row_size: Integer representing row size of the board
        
        Returns:
        - None
        """

        self.pick_valid_move_AI(row_size, property_locations, player)
        time.sleep(0.5)
        self.actions_option_AI(player, property_locations)
        time.sleep(0.5)

    def play_turns(self, property_locations:dict, row_size:int)-> None:
        """
        Runs full gameplay.
        
        Arguments:
        -property_location(dict): Dictionary that contains all the position-property key-value pairs
        -row_size(int): integer representing board size

        Returns:
        -None
        """
        check_win = False
        line = "*"*15
        
        #play turns and check win every end of the round until someone wins the game
        while check_win == False:
            quit_list = []  #reassign quit list every round

            if len(self.ALL_PLAYERS) != 0: #if there is player in the game 
                for player_index in range(len(self.ALL_PLAYERS)): #loop in every player
                    turn_done = False                             #turn_done set to false every round before start
                    while check_win == False and turn_done == False: 
                        #call play method -> play through the game and check whether it returns any remove_player
                        remove_player = self.play(self.ALL_PLAYERS[player_index], property_locations, row_size) 
                        #check win after every round based on winning_condition
                        check_win = self.ALL_PLAYERS[player_index].check_win(self.winning_condition)
                        #if there is some one in remove_player
                        if remove_player != None:
                            quit_list.append(remove_player) #append that player to quit list
                        turn_done = True    #set turn_done to true every round end

                #remove player if there is any
                for remove_player in quit_list:                 
                    for index in range(len(self.ALL_PLAYERS)): #loop through the list and compare
                        if remove_player == self.ALL_PLAYERS[index]: #if player == to remove player
                            delete_index = index               #delete index set to that looping index
                    del self.ALL_PLAYERS[delete_index]         #delete that index from ALL_PLAYERS
            
            for AI_index in range(len(self.AI_PLAYERS)):       #play turn for AI
                turn_done = False                              #turn_done = False every start of the round
                while check_win == False and turn_done == False:
                    self.play_AI(self.AI_PLAYERS[AI_index], property_locations, row_size) #play for AI
                    check_win = self.AI_PLAYERS[AI_index].check_win(self.winning_condition)#check win for AI every round ends
                    turn_done = True    #turn_done = True when the round ends
            
            #if all non-AI players have left the game and there are no AI players, game automatically ends      
            if len(self.ALL_PLAYERS) == 0 and len(self.AI_PLAYERS) == 0:
                #update check_win flag to True to jump out of while loop
                check_win = True
                #print statement
                print(line*2)
                time.sleep(0.3)
                print("ALL PLAYERS HAVE LEFT THE GAME.")
                time.sleep(0.3)
                print()
                print(line+"GAME ENDS"+line)
              
if __name__ == "__main__":
    # Test your function here
    game = PyPoly()

    
