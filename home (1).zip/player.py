#Author(s): Yew Jin Ruo, Teh Jia Xuan, Tan Jian Hao, Isha Maumoon
#Team: Musang King
#Date Edited: 2/1/2023

from property import Property
import math
import random
 
class Player:
    """
    Blueprint for all the players that will play the game.

    Class variables:
    STARTING_FUND - Integer to denote how much money each player starts with

    Instance variables of each Player object:
    - name (String) - represents name of the player 
    - symbol (String) - symbol to represent the player
    - fund (int) - represents how much money the player has
    - move_trait (String) - represents chosen move trait by the player
    - position (tuple) - represents the current position of the player on the board
    - properties_owned - list containing all the properties (Property instances) the player owns

    """

    #Instantiating class variables
    STARTING_FUND = 150
    
    #constructor (no input arguments)
    def __init__(self) -> None:
        #initialising instance variables to a specific value
        self.name = ""
        self.symbol = ""
        self.fund = self.STARTING_FUND
        self.move_trait = ""
        self.position = (None, None)
        self.properties_owned = []

    #getters to retrieve the value of all instance variables
    def get_name(self) -> str:
        """
        Returns the name of the player.

        Arguments:
        - None

        Returns:
        - self.name: Instance variable representing name of player (String)
        """
        return self.name

    def get_symbol(self) -> str:
        """
        Returns the symbol that represents the player.

        Arguments:
        - None

        Returns:
        - self.symbol: Instance variable representing the symbol of a player (String)
        """
        return self.symbol

    def get_fund(self) -> int:
        """
        Returns how much money a player has.

        Arguments:
        - None

        Returns:
        - self.fund: Instance variable representing how much money a player has (int)
        """
        return self.fund

    def get_properties_owned(self) -> list:
        """
        Returns a list containing all the properties (Property instances) the player owns.

        Arguments:
        - None

        Returns:
        - self.properties_owned: Instance variable containing all the properties (Property instances) the player owns (list)
        """
        return self.properties_owned

    def get_position(self) -> tuple:
        """
        Returns a tuple that represents the current position of the player on the board.

        Arguments:
        - None

        Returns:
        - self.position: Instance variable that represents the current position of the player on the board (tuple)
        """
        return self.position

    def get_move_trait(self) -> str:
        """
        Returns a String that represents the chosen move trait by the player.

        Arguments:
        - None

        Returns:
        - self.move_trait: Instance variable that represents the chosen move trait by the player (String)
        """
        return self.move_trait

    #setters to modify the values of instance variables name, symbol, position, properties_owned, move_trait
    def set_name(self, name: str) -> None:
        """
        Modifies the instance variable, name using the input String argument.

        Arguments:
        - name: String representing the name of the player

        Returns:
        - None
        """
        self.name = name

    def set_symbol(self, symbol: str) -> None:
        """
        Modifies the instance variable, symbol using the input String argument.

        Arguments:
        - symbol: String representing the symbol of the player

        Returns:
        - None
        """
        self.symbol = symbol

    def set_position(self, position: tuple) -> None:
        """
        Modifies the instance variable, position using the input tuple argument.

        Arguments:
        - position: Tuple representing the current position of the player on the board

        Returns:
        - None
        """
        self.position = position

    def set_properties_owned(self, property: Property) -> None:
        """
        Appends the the input property instance argument to the instance variable, properties_owned.

        Arguments:
        - property: property instance of class Property 

        Returns:
        - None
        """
        self.properties_owned.append(property)

    def set_move_trait(self, move_trait: str) -> None:
        """
        Modifies the instance variable, move_trait uing the input String argument.

        Arguments:
        - move_trait: String representing the chosen move_trait of a player 

        Returns:
        - None
        """
        self.move_trait = move_trait

    def add_fund(self, amount: int) -> None:
        """
        Add an amount of money to the player's fund.

        Arguments:
        - amount: Integer representing the amount of money to add to player's fund

        Returns:
        - None
        """
        self.fund += amount
    
    def reduce_fund(self, amount: int) -> None:
        """
        Reduce an amount of money from the player's fund.

        Arguments:
        - amount: Integer representing the amount of money to reduce from player's fund

        Returns:
        - None
        """

        self.fund -= amount

    def __str__(self) -> str:
        """
        Overriding __str__ function to use print() or str() on Player objects.

        Arguments:
        - None 

        Returns:
        - self.name: Instance variable representing name of player (String)
        """
        return self.name

    def __repr__(self) -> str:
        """
        Overriding __repr__ function, allows you to see the same string of your player.

        Arguments:
        - None 

        Returns:
        - self.__str__(): Calls __str__ function and returns its value
        """
        return self.__str__()

    def purchase_property(self, property: Property) -> None:
        """
        Compares the player's funds with the property's cost to check if the player can afford to purchase it.

        Arguments:
        - property: property instance of class Property 

        Returns:
        - None

        """
        #if player's funds >= property's cost, then buy property
        if (property.get_property_cost() <= self.get_fund()):
            self.properties_owned.append(property)                                      #append the property object to properties_owned
            self.reduce_fund(property.get_property_cost())                              #reduce fund of the player by property's cost
            property.set_owner(self)                                                    #set the owner of the property to the player itself
            print("{} purchased {}.".format(self.name, property.get_property_name()))   #print statement to let player know they have bought the property

        else:
            #if player's funds < property's cost, then let them know that they cannot purchase this property
            print("{} cannot purchase {} due to insufficient funds.".format(self.name, property.get_property_name()))

    def purchase_hotel(self, property: Property) -> None:
        """
        Compares the player's funds with the hotel's cost to check if the player can afford to purchase it. 

        Arguments:
        - property: property instance of class Property 

        Returns:
        - None
        """
        #if the property given in the argument is part of the player's properties owned
        if property in self.properties_owned:
            if (property.get_hotel_cost() <= self.fund):        #and the hotel cost of that property is <= player's fund, then buy hotel
                self.fund -= property.get_hotel_cost()          #deduct hotel cost from player's fund
                property.construct_hotel()                      #call construct_hotel to construct a hotel on the property
            else:
                print("{} cannot construct a hotel on {} due to insufficient funds.".format(self.name, property.get_property_name())) #if the hotel cost of that property is > player's fund, then inform player that they have insufficient funds
        
        #if property given in the argument is not part of the player's properties owned
        else:
            #let player know that they do not own this property
            print("{} must purchase {} before constructing a hotel.".format(self.name, property.get_property_name()))
            #call purchase_property to buy property
            self.purchase_property(property)


    def sell_property(self, property: Property) -> None:
        """
        Removes the property from the list, properties_owned of the player, 
        increase their fund and set the owner of the property to "Bank",
        and print a message confirming the sale.

        Arguments:
        - property: property instance of class Property 

        Returns:
        - None
        """
        #remove the property from the list, properties_owned of the playe
        self.properties_owned.remove(property)
        #get the value of the property
        amount = property.get_property_cost() + property.get_hotels_built() * property.get_hotel_cost()
        #add the value of the property sold to player's own fund
        self.add_fund(amount)
        #set the owner of the property back to the ORIGINAL_OWNER (Bank)
        property.owner = property.ORIGINAL_OWNER

    def display_player_properties(self):
        """
        displayer they properties owned 
        print total cost of hotel and property they owned
        print their available fund

        Arguments:
        - None

        Returns:
        - None
        """
        total_hotel_cost = 0
        total_property_cost = 0
        
        if (len(self.properties_owned) != 0):   #if owned property not = 0
            for colour in Property.COLOUR_GROUPS:   #enter loop by using colour
                counter = 0                         #counter set to 0 when it loops through diff colour
                for properties in self.properties_owned: #loop through the property they owned
                    if properties.get_colour_group() == colour: #if property colour is equal to the loop colour that we looping
                        counter += 1            #counter +1
                        if counter == 1:        #if counter == 1 
                            print(colour.upper())#then print capitalize colour (eg.BLUE) depends on the colour that looping in the loop
                        if counter >= 1:        #if counter >= 1
                            #output statement
                            print("{}. ${} {} (${} Hotels x {})".format(counter, properties.get_property_cost(), properties.get_property_name(), properties.get_hotel_cost(), properties.get_hotels_built()))
                            
                            #add current hotel cost and property cost of that property in that loop to total_hotel_cost and total_property_cost
                            total_hotel_cost += properties.get_hotel_cost() * properties.get_hotels_built()
                            total_property_cost += properties.get_property_cost()
        else:       #if they dont own any properties then ignore 
            pass
      
        #display total worth of properties and total worth of hotels
        print("TOTAL")
        print("${} worth of properties".format(total_property_cost))
        print("${} worth of hotels".format(total_hotel_cost))

    def check_win(self, winning_condition: int) -> None:
        """
        check whether have player win in that particular round
        print out statement

        Arguments:
        - winning_condition: number of properties in same colour and at least 1 hotel in that number of properties 
                             needed to win that match

        Returns:
        -check: True if someone wins that match if not false
        """
        for colour in Property.COLOUR_GROUPS:   #loop through every colour
            #reset check win and check after every colour
            check_win = 0
            check = True

            #check (winning_condition)eg.3 same colour property exist or no
            for properties in self.properties_owned: #loop throught properties they owned
                if properties.get_colour_group() == colour and properties.get_hotels_built() >= 1: #if colour and at least 1 hotel built in that property
                    check_win += 1                  #check win +1

            #if exist then check each have hotel or no
            if check_win >= winning_condition:   #if check win equal to winning condition then the player won
                print("Game Over! " + self.get_name() + " WINS!")#output statement
                return True #return True

            else:#if not check == false
                check = False

        check = False
        return check #return check

    def pay_rent(self, property: Property) -> None:
        """
        pay rent whether they landed on opponent's property
        fund decrease and increase opponent's fund
        if insufficient fund then give property to opponent
        if insufficient fund and dont have property
        set fund = 0

        Arguments:
        - property: property player landed on 

        Returns:
        - None
        """

        hotel_increase = (property.get_hotels_built() * 20) + 100 #if the property have any hotel 
        total_fund = property.get_rent_price() * (hotel_increase/100)#each hotel add 20% to the rent price
        
        if self.get_fund() >= total_fund:       #if player have sufficient fund for rent 
            self.reduce_fund(total_fund)        #then pay fund to opponent
            (property.get_owner()).add_fund(total_fund)#opponent's fund increase and output following statement
            print("{} paid ${} as a rental charge to {} and has ${} left.".format(self.get_name(),total_fund,property.get_owner(),self.get_fund()))

        elif self.get_fund() < total_fund:      #if player insufficient fund for rent 
            minimum = 100000000 #set minimum to 10000000
            lowest_value_property = ""          #then find lowest value property to give to opponent
            if len(self.get_properties_owned()) == 0:   #if player insufficient fund and have no properties
                self.reduce_fund(self.get_fund())       #then reduce player's fund to 0

            elif len(self.get_properties_owned()) > 0:  #if have properties
                for properties in self.get_properties_owned(): # loop through each property player has
                    total_cost_hotel = properties.get_hotels_built() * properties.get_hotel_cost() #calculate each property's value
                    total_value_property = properties.get_property_cost() + total_cost_hotel 
                    
                    if total_value_property < minimum: #if value of property less than minimum
                        minimum = total_value_property  #then set that property value to minimum
                        lowest_value_property = properties #and set lowest_value_property to that properties
                                                            #loop until lowest value property that the player has 

                self.properties_owned.remove(lowest_value_property) #remove that property from player's properties_owned list
                (property.get_owner()).properties_owned.append(lowest_value_property) #add that property to opponent's list
                #output statement
                print("{} does not have sufficient funds. {} gives {} to {} instead.".format(self.name, self.name, lowest_value_property, property.get_owner()))

    def determine_action(self, property_locations: dict)->bool:
        """
        determine action if they landed on some particular property
        or penalty or rewards and output appropriate statement

        Arguments:
        - property_location: Dictionary that contains all the position-property key-value pairs

        Returns:
        - bool: Return True if player landed on a property they can purchase or build hotels on. Returns False otherwise.
        """
        #get property and owner
        current_location = property_locations[self.get_position()] #get current location property by using dictionary
        player = current_location.get_owner()   #set player to that current_location owner
        
        #Penalty
        if current_location.get_property_name() == "Penalty":   #if landed on penalty
            penalty_percentage = random.randint(5,30)/100       #penalty is 5 to 30 percent of player's fund
            penalty_amount = round(self.get_fund() * (penalty_percentage))
            self.reduce_fund(penalty_amount)                    #reduce fund of that player
            print("{} landed on Penalty and has been fined ${}.".format(self.get_name(), penalty_amount)) #output statement
            return False    #return false

        #rewards
        elif current_location.get_property_name() == "Reward": #if landed on reward
            reward_amount = random.randint(30,150)             #reward is 30 to 150
            self.add_fund(reward_amount)                       #add to fund
            print("{} landed on Reward and has been rewarded ${}.".format(self.get_name(), reward_amount))
            return False    #return false

        #check owner, do actions
        elif player == "Bank":  #check owner is bank or not
            print("{} landed on {}.".format(self.get_name(), current_location.get_property_name()))
            return True         #return true if it is
        
        elif player == self.get_name(): #if current location is player
            print("{} landed on {}, a property that they own.".format(self.get_name(), current_location.get_property_name()))
            return True                 #return True

        elif player != self and player != "Bank":   #if current location is not player and not bank 
            print("{} landed on {}, a property owned by {}.".format(self.get_name(), current_location.get_property_name(), current_location.get_owner()))
            self.pay_rent(current_location)         #then pay rent and return false
            return False



    
    
    

