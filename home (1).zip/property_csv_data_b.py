#do not edit

delimiter = '|'
csv_data = [
"rent_price|property_cost|hotel_cost|property_name|key|colour_group",
"30|40|35|Blueberry Boulevard|blue_blvd|Blue",
"40|60|55|elderberries express|elder_exp|Blue",
"35|50|40|Pea Flower pavement|pea_pm|Blue",
"100|125|110|potato pathway|potato_pw|Blue",
"120|190|180|Starflower street|star_st|Blue",
"70|65|70|taro trail|taro_tr|Blue",
"60|85|70|Avocado Avenue|avo_ave|Green",
"45|50|45|brocolli bypass|broco_byp|Green",
"40|55|50|cabbage culdesac|cabb_culd|Green",
"70|100|80|cucumber crossroad|cucumb_cr|Green",
"110|150|130|pandan pavement|pandan_pm|Green",
"90|120|110|spinach street|spinach_st|Green",
"90|115|120|chilli crossroad|chilli_cr|Red",
"100|200|180|doughnut driveway|dough_dr|Red",
"50|45|50|passionfruit pavement|passion_pm|Red",
"90|85|100|rhubarb roadway|rhubard_rd|Red",
"55|70|60|strawberry street|straw_st|Red",
"45|60|50|Watermelon walkway|water_wa|Red",
"20|40|30|Butter boulevard|butter_blvd|Yellow",
"25|40|30|lemon lane|lemon_ln|Yellow",
"110|150|135|pineapple pathway|pine_pw|Yellow",
"80|100|90|Saffron straits|saffron_st|Yellow",
"50|60|55|sundae street|sundae_st|Yellow",
"90|130|120|Turmeric trail|turm_tr|Yellow"]
