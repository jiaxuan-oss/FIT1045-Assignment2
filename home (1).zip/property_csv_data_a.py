#do not edit

delimiter = '/'
csv_data = [
"key/property_name/property_cost/hotel_cost/rent_price/colour_group",
"atlantic_ave/Atlantic Avenue/100/110/45/Blue",
"med_ave/Mediterranean Avenue/20/30/5/Blue",
"boulevard_ave/Oriental Avenue/180/190/85/Blue",
"penn_ave/Pennsylvania Avenue/140/150/65/Blue",
"st_james_place/St. James Place/60/70/25/Blue",
"kentucky_ave/Kentucky Avenue/70/80/30/Green",
"man_place/Mansfield Place/220/230/110/Green",
"marvin_gardens/Marvin Gardens/110/120/50/Green",
"oriental_ave/Oriental Avenue/30/40/10/Green",
"park_place/Park Place/150/160/70/Green",
"vermont_ave/Vermont Avenue/190/200/90/Green",
"boardwalk/Boardwalk/160/170/75/Red",
"conn_ave/Connecticut Avenue/200/210/95/Red",
"indiana_ave/Indiana Avenue/80/90/35/Red",
"pacific_ave/Pacific Avenue/120/130/55/Red",
"st_charles_place/St. Charles Place/40/50/15/Red",
"baltic_ave/Baltic Avenue/170/180/80/Yellow",
"illinois_ave/Illinois Avenue/90/100/40/Yellow",
"nc_ave/North Carolina Avenue/130/140/60/Yellow",
"states_ave/States Avenue/50/60/20/Yellow",
"ten_ave/Tennessee Avenue/210/220/100/Yellow"]
