#Author(s): Yew Jin Ruo, Teh Jia Xuan, Tan Jian Hao, Isha Maumoon
#Team: Musang King
#Date Edited: 2/1/2023

class Property:
    """
    Blueprint for all the properties that created

    Class variables:
    ORIGINAL_OWNER - String representing the one who owns the property at first (Bank)
    COLOUR_GROUPS - List containing all colours of the properties

    Instance variable for each property object:
    - property_name(String)- represent name for property object
    - property_cost(int) - represent cost for property
    - hotel_cost(int) - represent hotel for each property
    - rent_price(int) - represent property's rent price
    - colour_group(str) - represent property's colour
    - hotel_built(int) - number of hotel built at that property
    - location(tuple) - location of property within the board
    - owner(str) - owner of the property
    """

    #Instantiating class variables
    ORIGINAL_OWNER = "Bank"
    COLOUR_GROUPS = ["Blue", "Green", "Red", "Yellow"]

    #constructor (with input arguments: property_name, property_cost, hotel_cost, rent_price, colour_group)
    def __init__(self, property_name: str, property_cost: int, hotel_cost: int, rent_price: int, colour_group: str) -> None:
        #initialising instance variables to a specific value
        self.property_name = property_name.title()
        self.property_cost = property_cost
        self.hotel_cost = hotel_cost
        self.rent_price = rent_price
        self.colour_group = colour_group
        self.hotels_built = 0
        self.location = (None, None)
        self.owner = self.ORIGINAL_OWNER

    #getters to retrieve the value of all instance variables
    def get_property_name(self) -> str:
        """
        Returns the name of the property,

        Arguments:
        - None

        Returns:
        - self.property_name: String representing the name of the property
        """
        return self.property_name

    def get_property_cost(self) -> int:
        """
        Returns the cost of property.

        Arguments:
        - None

        Returns:
        - self.property_cost: Integer representing the cost of that property
        """
        return self.property_cost

    def get_hotel_cost(self) -> int:
        """
        Returns hotel cost for that property.

        Arguments:
        - None

        Returns:
        - self.hotel_cost: Integer representing the hotel cost for that property
        """
        return self.hotel_cost

    def get_hotels_built(self) -> int:
        """
        Returns number of hotels built in that property.

        Arguments:
        - None

        Returns:
        - self.hotels_built: Integer representing the number of hotels built in that property
        """
        return self.hotels_built

    def get_rent_price(self) -> int:
        """
        Returns rent price of that property.

        Arguments:
        - None

        Returns:
        - self.rent_price: Integer representing the rent price for that property
        """
        return self.rent_price

    def get_colour_group(self) -> str:
        """
        Returns colour group of that property.

        Arguments:
        - None

        Returns:
        - self.colour_group: String representing the colour group of that property
        """
        return self.colour_group

    def get_owner(self) -> object:
        """
        Returns owner of that property

        Arguments:
        - None

        Returns:
        - self.owner: String representing owner of that property
        """
        return self.owner

    def get_location(self) -> tuple:
        """
        Return location of that property

        Arguments:
        - None

        Returns:
        - self.location: tuple representing location of that property
        """
        return self.location

    #setters to modify the values of instance variables owner, rent_price, location
    def set_owner(self, owner) -> None:
       """
       Modifies the instance variable, owner using the input string argument
       
       Arguments:
       - owner: represent owner of the property
       
       Returns:
       - None
       """
       self.owner = owner

    def set_rent_price(self, rent_price: int) -> None:
        """
        Modifies the instance variable, rent_price using the input string argument

        Arguments:
        - rent_price: represent rent price of that property

        Returns:
        - None
        """
        self.rent_price = rent_price

    def set_location(self, location: tuple) -> None:
        """
        Modifies the instance variable, location using input string argument

        Arguments:
        - location: represent location of that property

        Returns:
        - None
        """
        self.location = location

    def construct_hotel(self) -> None:
        """
        construct a hotel for that property

        Arguments:
        -None

        Returns:
        - None
        """
        if (self.hotels_built == 0):                                                                #check if hotel built for that property = 0 
            self.hotels_built += 1                                                                  #add one to hotel_built
            print("{} hotel has been built on {}.".format(self.hotels_built, self.property_name))   #output statement
        elif (self.hotels_built == 1):                                                              #if hotels built = 1
            self.hotels_built += 1                                                                  #addone to hotel built 
            print("{} hotels have been built on {}.".format(self.hotels_built, self.property_name)) #output statement

        elif (self.hotels_built >= 2):                                                              #if hotel is 2 or more
            print("The maximum number of hotels have been built on {}".format(self.property_name))  #output statement


    def __str__(self) -> str:
        """
        Overriding __str__ function to use print() or str() on property objects.

        Arguments:
        - None 

        Returns:
        - self.property_name: instance variable represent property name (string)
        """
        return self.property_name

    def __repr__(self) -> str:
        """
        Overriding __repr__ function, allows you to see the same string of your property

        Arguments:
        - None 

        Returns:
        - self.__str__(): Calls __str__ function and returns its value
        """
        return self.__str__()


