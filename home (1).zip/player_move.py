#Author(s): Yew Jin Ruo, Teh Jia Xuan, Tan Jian Hao, Isha Maumoon
#Team: Musang King
#Date Edited: 2/1/2023

from player import Player
 
class PerpendicularPlayer(Player):
    """
    Inherits the Player class.
    Blueprint for all players that move perpendicularly (if any).

    Class variables:
    -BASE_MOVE_TRAIT: String that stores the move trait of the player

    Instance variables of each PerpendicularPlayer object (excluding inherited instance variables):
    - move_trait (String): represents the move trait of the PerpendicularPlayer object ("Perpendicular")
    """

    #Instantiating class variables
    BASE_MOVE_TRAIT = "Perpendicular"

    #constructor (no input arguments)
    def __init__(self) -> None:
        #instantiates a Player class object
        super().__init__()
        #initialising instance variables to a specific value
        self.move_trait = self.BASE_MOVE_TRAIT

    def determine_valid_moves(self, row_size: int) -> list[tuple]:
        """
        Determines all the valid moves of PerpendicularPlayer, depending on the row_size of the board, 
        the current position of the user and their move_trait.

        Arguments:
        - row_size: Integer representing the row size of the board

        Returns:
        - valid_moves: A list of tuples representing all positions of valid moves
        """
        #get current position of the PerpendicularPlayer
        (x,y) = self.position
        #valid_moves - List instantiated to store all coordinates of valid moves
        valid_moves = []

        #PerpendicularPlayer can only move 1 grid vertically or horizontally
        if (((y+1) > 0) and ((y+1) < row_size)):        #checking if moving horizontally right is possible and append the position to valid_moves if it is
            valid_moves.append((x,(y+1)))               
        if (((x+1) > 0) and ((x+1) < row_size)):        #checking if moving vertically downwards is possible and append the position to valid_moves if it is
            valid_moves.append(((x+1),y))
        if (((x-1) >= 0) and ((x-1) < row_size)):       #checking if moving vertically upwards is possible and append the position to valid_moves if it is
            valid_moves.append(((x-1),y))
        if (((y-1) >= 0) and ((y-1) < row_size)):       #checking if moving horizontally left is possible and append the position to valid_moves if it is       
            valid_moves.append((x,(y-1)))

        #return list of valid moves
        return valid_moves
    
    def format_header_row(self, row_size: int) -> None:
        """
        Prints the header row of the printed board using the row_size of the board given.
        
        Arguments:
        - row_size: Integer representing the row size of the board

        Returns:
        - None
        """
        #spaces used to print the spaces between each number, 3 for row_size < 10 and 2 for row_size >= 10
        spaces_between_3 = 3*" "
        spaces_between_2 = 2*" "

        if row_size < 10:
            #if the row_size < 10, add 4 spaces to the front of the haeder_row string
            header_row = 4*" "
        else:
            #if the row_size >= 10, add 5 spaces to the front of the header_row string
            header_row = 5*" "
        
        #for each row add the row number + spaces to format the header row
        for row in range(row_size):
            if row < 9: 
                header_row += (str(row) + spaces_between_3)     #for row_size less than 9 add 3 spaces to align
            else:
                header_row += (str(row) + spaces_between_2)     #for row_size larger than 9 add 2 spaces to align 
        
        #print the completed header_row
        print(header_row)

    def format_board_line(self, row_size: int) -> None:
        """
        Prints one board line of the board using the row_size of the board given.
        
        Arguments:
        - row_size: Integer representing the row size of the board

        Returns:
        - None

        """
        #alignment of row_sizes >=10 and <10
        #if the row_size < 10, add 2 spaces to the board line and a "+" symbol
        #if the row_size >= 10, add 3 spaces to the board line and a "+" symbol (making room for double digit numbers)
        if row_size < 10:
            board_line = (2*" ") + "+"
        else:
            board_line = (3*" ") + "+"
        
        #for each row, add a "---+" to the board line
        for row in range(row_size):
            board_line += "---+"

        #print the formatted board line
        print(board_line)
    
    def display_moves(self, row_size: int, valid_flag: bool) -> None:
        """
        Display the PyPoly board at every player's turn,
        display their current position as their own symbol and 
        display all valid moves when valid_flag is True only.

        Arguments:
        - row_size: Integer representing the row size of the board
        - valid_flag: Boolean value representing if the valid moves should be printed on the board or not

        Returns:
        - None
        """
        #space - used to store a space (used for printing)
        space = " "
        #row_marker- used to close a column
        row_marker = (3*" ") + "|"
        #call determine_valid_moves to get all coordinates of valid moves
        valid_moves = self.determine_valid_moves(row_size)

        #print the header row
        self.format_header_row(row_size)
        #print the first board line
        self.format_board_line(row_size)
        #get current position of the player
        (x,y) = self.position

        #if the flag is False, valid moves are not printed on the board
        if valid_flag == False:
            #for each row in row size of the board print the row number and a "|"
            for row in range(row_size):
                #print_row - used to store the string for each row that needs to be printed
                #add an extra space to the print_row string if row size >= 10 (alignment of double digits)
                if row_size >= 10:
                    if row < 10:
                        print_row = str(row) + 2*space + "|"
                    else:
                        print_row = str(row) + space + "|"
                else:
                    print_row = str(row) + space + "|"
                
                #using the print_row string that has the row number appended, add a row_marker for each column in row_size
                for column in range(row_size):
                    #if the position is the current position of the player, print its symbol in the box
                    if ((row == x) and (column == y)): 
                        print_row += space + self.symbol + space + "|"

                    else:
                        print_row += row_marker     #if not, print the row_marker only

                #print the formatted row string
                print(print_row)
                #print a board line after each row is printed, then loop back to print until last row
                self.format_board_line(row_size)

        #if the flag is True, valid moves are printed on the board
        else: 
            #for each row in row size of the board print the row number and a "|"
            for row in range(row_size):
                #print_row - used to store the string for each row that needs to be printed
                #add an extra space to the print_row string if row size >= 10 (alignment of double digits)
                if row_size >= 10:
                    if row < 10:
                        print_row = str(row) + 2*space + "|"
                    else:
                        print_row = str(row) + space + "|"
                else:
                    print_row = str(row) + space + "|"

                #using the print_row string that has the row number appended, add a row_marker for each column in row_size
                for column in range(row_size):
                    #if the position is the current position of the player, print its symbol in the box
                    if ((row == x) and (column == y)):
                        print_row += space + self.symbol + space + "|"

                    #if the position is one of the valid moves of the player, print "x" in the box
                    elif ((row,column) in valid_moves):
                        print_row += space + "x" + space + "|"

                    else:
                        print_row += row_marker     #if not, print the row_marker only

                #print the formatted row string
                print(print_row)
                #print a board line after each row is printed, then loop back to print until last row
                self.format_board_line(row_size) 
        print()
 
class DiagonalPlayer(Player):
    """
    Inherits the Player class.
    Blueprint for all players that move diagonally (if any).

    Class variables:
    -BASE_MOVE_TRAIT: String that stores the move trait of the player

    Instance variables of each DiagonalPlayer object (excluding inherited instance variables):
    - move_trait (String): represents the move trait of the DiagonalPlayer object ("Diagonal")
    """

    #Instantiating class variables
    BASE_MOVE_TRAIT = "Diagonal"
    
    #constructor (no input arguments)
    def __init__(self) -> None:
        #instantiates a Player class object
        super().__init__()
        #initialising instance variables to a specific value
        self.move_trait = self.BASE_MOVE_TRAIT

    def determine_valid_moves(self, row_size: int) -> list[tuple]:
        """
        Determines all the valid moves of the DiagonalPlayer, depending on the row_size of the board, 
        the current position of the user and their move_trait.

        Arguments:
        - row_size: Integer representing the row size of the board

        Returns:
        - valid_moves: A list of tuples representing all positions of valid moves
        """
        #get current position of the DiagonalPlayer
        (x,y) = self.position
        #valid_moves - List instantiated to store all coordinates of valid moves
        valid_moves = []

        #DiagonalPlayer can only move 1 grid diagonally
        if (((x-1) >= 0) and ((x-1) < row_size) and ((y-1) >= 0) and ((y-1) < row_size)):       #checking if moving up left is possible and append the position to valid_moves if it is
            valid_moves.append(((x-1),(y-1)))
        if (((x+1) > 0) and ((x+1) < row_size) and ((y+1) > 0) and ((y+1) < row_size)):         #checking if moving down right is possible and append the position to valid_moves if it is
            valid_moves.append(((x+1),(y+1)))
        if (((x-1) >= 0) and ((x-1) < row_size) and ((y+1) > 0) and ((y+1) < row_size)):        #checking if moving up right is possible and append the position to valid_moves if it is
            valid_moves.append(((x-1),(y+1)))
        if (((x+1) > 0) and ((x+1) < row_size) and ((y-1) >= 0) and ((y-1) < row_size)):        #checking if moving down left is possible and append the position to valid_moves if it is
            valid_moves.append(((x+1),(y-1)))

        #return list of valid moves
        return valid_moves

    def format_header_row(self, row_size: int) -> None:
        """
        Prints the header row of the printed board using the row_size of the board given.
        
        Arguments:
        - row_size: Integer representing the row size of the board

        Returns:
        - None
        """
        #spaces used to print the spaces between each number, 3 for row_size < 10 and 2 for row_size >= 10
        spaces_between_3 = 3*" "
        spaces_between_2 = 2*" "

        if row_size < 10:
            #if the row_size < 10, add 4 spaces to the front of the haeder_row string
            header_row = 4*" "
        else:
            #if the row_size >= 10, add 5 spaces to the front of the header_row string
            header_row = 5*" "
        
        #for each row add the row number + spaces to format the header row
        for row in range(row_size):
            if row < 9: 
                header_row += (str(row) + spaces_between_3)     #for row_size less than 9 add 3 spaces to align
            else:
                header_row += (str(row) + spaces_between_2)     #for row_size larger than 9 add 2 spaces to align 
        
        #print the completed header_row
        print(header_row)

    def format_board_line(self, row_size: int) -> None:
        """
        Prints one board line of the board using the row_size of the board given.
        
        Arguments:
        - row_size: Integer representing the row size of the board

        Returns:
        - None

        """
        #alignment of row_sizes >=10 and <10
        #if the row_size < 10, add 2 spaces to the board line and a "+" symbol
        #if the row_size >= 10, add 3 spaces to the board line and a "+" symbol (making room for double digit numbers)
        if row_size < 10:
            board_line = (2*" ") + "+"
        else:
            board_line = (3*" ") + "+"
        
        #for each row, add a "---+" to the board line
        for row in range(row_size):
            board_line += "---+"

        #print the formatted board line
        print(board_line)
    
    def display_moves(self, row_size: int, valid_flag: bool) -> None:
        """
        Display the PyPoly board at every player's turn,
        display their current position as their own symbol and 
        display all valid moves when valid_flag is True only.

        Arguments:
        - row_size: Integer representing the row size of the board
        - valid_flag: Boolean value representing if the valid moves should be printed on the board or not

        Returns:
        - None
        """
        #space - used to store a space (used for printing)
        space = " "
        #row_marker- used to close a column
        row_marker = (3*" ") + "|"
        #call determine_valid_moves to get all coordinates of valid moves
        valid_moves = self.determine_valid_moves(row_size)

        #print the header row
        self.format_header_row(row_size)
        #print the first board line
        self.format_board_line(row_size)
        #get current position of the player
        (x,y) = self.position

        #if the flag is False, valid moves are not printed on the board
        if valid_flag == False:
            #for each row in row size of the board print the row number and a "|"
            for row in range(row_size):
                #print_row - used to store the string for each row that needs to be printed
                #add an extra space to the print_row string if row size >= 10 (alignment of double digits)
                if row_size >= 10:
                    if row < 10:
                        print_row = str(row) + 2*space + "|"
                    else:
                        print_row = str(row) + space + "|"
                else:
                    print_row = str(row) + space + "|"
                
                #using the print_row string that has the row number appended, add a row_marker for each column in row_size
                for column in range(row_size):
                    #if the position is the current position of the player, print its symbol in the box
                    if ((row == x) and (column == y)): 
                        print_row += space + self.symbol + space + "|"

                    else:
                        print_row += row_marker     #if not, print the row_marker only

                #print the formatted row string
                print(print_row)
                #print a board line after each row is printed, then loop back to print until last row
                self.format_board_line(row_size)

        #if the flag is True, valid moves are printed on the board
        else: 
            #for each row in row size of the board print the row number and a "|"
            for row in range(row_size):
                #print_row - used to store the string for each row that needs to be printed
                #add an extra space to the print_row string if row size >= 10 (alignment of double digits)
                if row_size >= 10:
                    if row < 10:
                        print_row = str(row) + 2*space + "|"
                    else:
                        print_row = str(row) + space + "|"
                else:
                    print_row = str(row) + space + "|"

                #using the print_row string that has the row number appended, add a row_marker for each column in row_size
                for column in range(row_size):
                    #if the position is the current position of the player, print its symbol in the box
                    if ((row == x) and (column == y)):
                        print_row += space + self.symbol + space + "|"

                    #if the position is one of the valid moves of the player, print "x" in the box
                    elif ((row,column) in valid_moves):
                        print_row += space + "x" + space + "|"

                    else:
                        print_row += row_marker     #if not, print the row_marker only

                #print the formatted row string
                print(print_row)
                #print a board line after each row is printed, then loop back to print until last row
                self.format_board_line(row_size) 

        print()
    
class LPlayer(Player):
    """
    Inherits the Player class.
    Blueprint for all players that move in an L shape (if any).

    Class variables:
    -BASE_MOVE_TRAIT: String that stores the move trait of the player

    Instance variables of each LPlayer object (excluding inherited instance variables):
    - move_trait (String): represents the move trait of the LPlayer object ("L")
    """

    #Instantiating class variables
    BASE_MOVE_TRAIT = "L"
    
    #constructor (no input arguments)
    def __init__(self) -> None:
        #instantiates a Player class object
        super().__init__()
        #initialising instance variables to a specific value
        self.move_trait = self.BASE_MOVE_TRAIT

    def determine_valid_moves(self, row_size: int) -> list[tuple]:
        """
        Determines all the valid moves of the LPlayer, depending on the row_size of the board, 
        the current position of the user and their move_trait.

        Arguments:
        - row_size: Integer representing the row size of the board

        Returns:
        - valid_moves: A list of tuples representing all positions of valid moves
        """
        #get current position of the LPlayer
        (x,y) = self.position
        #valid_moves - List instantiated to store all coordinates of valid moves
        valid_moves = []

        #LPlayer can only move 2 grids vertically and 1 grid horizontally, or 2 grids horizontally and 1 grid vertically (forming the shape of an "L")
        #1: check if moving 2 spaces up, 1 space left is possible, and append coordinate to valid_moves if it is
        if (((x-2) >= 0) and ((x-2) < row_size) and ((y-1) >= 0) and ((y-1) < row_size)):
            valid_moves.append(((x-2),(y-1))) 
        
        #2: check if moving 2 spaces right, 1 space down is possible, and append coordinate to valid_moves if it is
        if (((x+1) > 0) and ((x+1) < row_size) and ((y+2) > 0) and ((y+2) < row_size)):
            valid_moves.append(((x+1),(y+2))) 

        #3: check if moving 2 spaces down, 1 space right is possible, and append coordinate to valid_moves if it is
        if (((x+2) > 0) and ((x+2) < row_size) and ((y+1) > 0) and ((y+1) < row_size)):
            valid_moves.append(((x+2),(y+1))) 
        
        #4: check if moving 2 spaces up, 1 space right is possible, and append coordinate to valid_moves if it is
        if (((x-2) >= 0) and ((x-2) < row_size) and ((y+1) > 0) and ((y+1) < row_size)):
            valid_moves.append(((x-2),(y+1))) 

        #5: check if moving 2 spaces right, 1 space up is possible, and append coordinate to valid_moves if it is
        if (((x-1) >= 0) and ((x-1) < row_size) and ((y+2) > 0) and ((y+2) < row_size)):
            valid_moves.append(((x-1),(y+2))) 
        
        #6: check if moving 2 spaces left, 1 space down is possible, and append coordinate to valid_moves if it is
        if (((x+1) > 0) and ((x+1) < row_size) and ((y-2) >= 0) and ((y-2) < row_size)):
            valid_moves.append(((x+1),(y-2))) 

        #7: check if moving 2 spaces left, 1 space up is possible, and append coordinate to valid_moves if it is
        if (((x-1) >= 0) and ((x-1) < row_size) and ((y-2) >= 0) and ((y-2) < row_size)):
            valid_moves.append(((x-1),(y-2))) 
        
        #8: check if moving 2 spaces down, 1 space left is possible, and append coordinate to valid_moves if it is
        if (((x+2) > 0) and ((x+2) < row_size) and ((y-1) >= 0) and ((y-1) < row_size)):
            valid_moves.append(((x+2),(y-1))) 

        #return list of valid moves
        return valid_moves

    def format_header_row(self, row_size: int) -> None:
        """
        Prints the header row of the printed board using the row_size of the board given.
        
        Arguments:
        - row_size: Integer representing the row size of the board

        Returns:
        - None
        """
        #spaces used to print the spaces between each number, 3 for row_size < 10 and 2 for row_size >= 10
        spaces_between_3 = 3*" "
        spaces_between_2 = 2*" "

        if row_size < 10:
            #if the row_size < 10, add 4 spaces to the front of the haeder_row string
            header_row = 4*" "
        else:
            #if the row_size >= 10, add 5 spaces to the front of the header_row string
            header_row = 5*" "
        
        #for each row add the row number + spaces to format the header row
        for row in range(row_size):
            if row < 9: 
                header_row += (str(row) + spaces_between_3)     #for row_size less than 9 add 3 spaces to align
            else:
                header_row += (str(row) + spaces_between_2)     #for row_size larger than 9 add 2 spaces to align 
        
        #print the completed header_row
        print(header_row)

    def format_board_line(self, row_size: int) -> None:
        """
        Prints one board line of the board using the row_size of the board given.
        
        Arguments:
        - row_size: Integer representing the row size of the board

        Returns:
        - None

        """
        #alignment of row_sizes >=10 and <10
        #if the row_size < 10, add 2 spaces to the board line and a "+" symbol
        #if the row_size >= 10, add 3 spaces to the board line and a "+" symbol (making room for double digit numbers)
        if row_size < 10:
            board_line = (2*" ") + "+"
        else:
            board_line = (3*" ") + "+"
        
        #for each row, add a "---+" to the board line
        for row in range(row_size):
            board_line += "---+"

        #print the formatted board line
        print(board_line)
        
    
    def display_moves(self, row_size: int, valid_flag: bool) -> None:
        """
        Display the PyPoly board at every player's turn,
        display their current position as their own symbol and 
        display all valid moves when valid_flag is True only.

        Arguments:
        - row_size: Integer representing the row size of the board
        - valid_flag: Boolean value representing if the valid moves should be printed on the board or not

        Returns:
        - None
        """
        #space - used to store a space (used for printing)
        space = " "
        #row_marker- used to close a column
        row_marker = (3*" ") + "|"
        #call determine_valid_moves to get all coordinates of valid moves
        valid_moves = self.determine_valid_moves(row_size)

        #print the header row
        self.format_header_row(row_size)
        #print the first board line
        self.format_board_line(row_size)
        #get current position of the player
        (x,y) = self.position

        #if the flag is False, valid moves are not printed on the board
        if valid_flag == False:
            #for each row in row size of the board print the row number and a "|"
            for row in range(row_size):
                #print_row - used to store the string for each row that needs to be printed
                #add an extra space to the print_row string if row size >= 10 (alignment of double digits)
                if row_size >= 10:
                    if row < 10:
                        print_row = str(row) + 2*space + "|"
                    else:
                        print_row = str(row) + space + "|"
                else:
                    print_row = str(row) + space + "|"
                
                #using the print_row string that has the row number appended, add a row_marker for each column in row_size
                for column in range(row_size):
                    #if the position is the current position of the player, print its symbol in the box
                    if ((row == x) and (column == y)): 
                        print_row += space + self.symbol + space + "|"

                    else:
                        print_row += row_marker     #if not, print the row_marker only

                #print the formatted row string
                print(print_row)
                #print a board line after each row is printed, then loop back to print until last row
                self.format_board_line(row_size)

        #if the flag is True, valid moves are printed on the board
        else: 
            #for each row in row size of the board print the row number and a "|"
            for row in range(row_size):
                #print_row - used to store the string for each row that needs to be printed
                #add an extra space to the print_row string if row size >= 10 (alignment of double digits)
                if row_size >= 10:
                    if row < 10:
                        print_row = str(row) + 2*space + "|"
                    else:
                        print_row = str(row) + space + "|"
                else:
                    print_row = str(row) + space + "|"

                #using the print_row string that has the row number appended, add a row_marker for each column in row_size
                for column in range(row_size):
                    #if the position is the current position of the player, print its symbol in the box
                    if ((row == x) and (column == y)):
                        print_row += space + self.symbol + space + "|"

                    #if the position is one of the valid moves of the player, print "x" in the box
                    elif ((row,column) in valid_moves):
                        print_row += space + "x" + space + "|"

                    else:
                        print_row += row_marker     #if not, print the row_marker only

                #print the formatted row string
                print(print_row)
                #print a board line after each row is printed, then loop back to print until last row
                self.format_board_line(row_size) 

        print()

