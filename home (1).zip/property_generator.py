#Author(s): Yew Jin Ruo, Teh Jia Xuan, Tan Jian Hao, Isha Maumoon
#Team: Musang King
#Date Edited: 2/1/2023

from property import Property
import random
import math
from property_csv_data_a import csv_data


class PropertyGenerator:
    """
    Blueprint for all the properties that are generated.

    Class variables:
    - None

    Instance variables of each Player object:
    - properties(list): Represents list of properties that generated
    - property_locations(dictionary): Dictionary where keys represent coordinate and values represent property instance
    - number_of_locations(int): Integer that represents the number of locations available
    """

    
    def __init__(self) -> None:
        """
        Store all the instance variables.

        Arguments:
        -None

        Returns:
        -None
        """

        self.properties = []
        self.property_locations = {}
        self.number_of_locations = 0
    
    def csv_to_properties(self, data: list, delimiter: str) -> None:
        """
        Store all the instance variables.

        Arguments:
        -data: csv_data contains details of properties
        -delimeter: symbol used to split the data in csv_data

        Returns
        -None
        """
        
        rent_price = 0
        property_cost = 0
        hotel_cost = 0
        property_name = 0
        key = 0
        colour_group = 0

        header = data[0] #get header of csv_data
        header_split = header.split(delimiter) #split header into list by using delimeter
      
        for column in range(len(header_split)):         #loop into header to know every column represents
            if "rent_price" in header_split[column]:    #if the keyword is in that column of header_split list 
                rent_price = column                     #set that column to that property

            elif "property_cost" in header_split[column]: 
                property_cost = column

            elif "hotel_cost" in header_split[column]:
                hotel_cost = column

            elif "property_name" in header_split[column]:
                property_name = column

            elif "key" in header_split[column]:
                key = column

            elif "colour_group" in header_split[column]:
                colour_group = column
       
        for row in data[1:]:                            #loop into csv_data from 2nd row onwards (except header row)
            split_data = row.strip().split(delimiter)   #split data into list 
            for index in range(len(split_data)):        #loop into split_data
                replace_char = ""                       
                for char in split_data[index]:          #loop into every character in same
                    if char != "\"" and char != ",":    #get rid of everything except the keyword
                        replace_char += char            #add alphabet only to replace_char
                        
                split_data[index] = replace_char        #replace it back

            #create all property object from csv_data and append to self.properties
            self.properties.append(Property(split_data[property_name], int(split_data[property_cost]), int(split_data[hotel_cost]), int(split_data[rent_price]), split_data[colour_group]))
        

    def property_location_generator(self) -> None:
        """
        Generate location for each property
        
        Arguments:
        -None

        Return:
        -None
        """
        number_properties = len(self.properties) #get number of properties
        number_properties += 4                   # add 4 as it requires at least 4 chances
        flag = True                             
        check = True
        counter = 0
        nearest_square = 0
        index = 0

        #get minimum square number based on number of location
        while flag == True:                     
            counter += 1                        #add one to counter everytime it loops
                                                #counter act as number before square. 
            square = math.pow(counter,2)        #square counter 
            if square >= number_properties:     #if square more than number of properties 
                self.number_of_locations = int(square) #number of locations set to square
                flag = False                    #jump out of loop
        
        #get number of chances 
        each_penalty_reward = self.number_of_locations - len(self.properties) #get number of chance grids
        
        #create chances 
        for num in range(each_penalty_reward): #loop through chances
            if num%2 == 0:
                all_penalty_reward = Property("Penalty",None,None,None,None) #create penalty object if num is even number
                self.properties.append(all_penalty_reward)                   #append to self.properties
            
            elif num%2 != 0:
                all_penalty_reward = Property("Reward",None,None,None,None) #create reward object if num is odd number
                self.properties.append(all_penalty_reward)                  #append to self.properties

        #assign x and y to every grid
        while check == True:
            x = random.randint(0,counter-1)                                 #assign location to every property object
            y = random.randint(0,counter-1)                                 #by using counter that loop through for loop above      
                                                                            #so that the location will within counter x counter table
            if (x, y) not in self.property_locations.keys():                #if location (x,y) not in key then
                self.property_locations[x,y] = self.properties[index]       #assign (x,y) to property object
                index += 1                                                  #by setting (x,y) as key and property object as value
                if index == len(self.properties):                           #if index same as length which means it already until the end of the list
                    check = False                                           #escape out of loop
                    
        sorted_dic = sorted(self.property_locations.items())                #sort location 
                
        #for key,values in sorted_dic:                                      #print when necessary
            #print("{} {}".format(key,values))                              #print key value of location when testing
        


    



