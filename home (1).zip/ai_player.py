#Author(s): Yew Jin Ruo, Teh Jia Xuan, Tan Jian Hao, Isha Maumoon
#Team: Musang King
#Date Edited: 2/1/2023

from player_move import LPlayer
from player import Player
from property import Property
import random
import math
 
class AIPlayer(LPlayer):
    """
    Inherits the LPlayer class (AI Player moves in an L-shape).
    Blueprint for all AI players playing the game (if any).
    
    Class variables:
    - None 

    Instance variables of each AIPlayer object (excluding inherited instance variables):
    - colour_groups (list): a list of all colour groups from Property class
    - move_record (list): a list of past moves done by the AI player

    """

    #constructor (no input arguments)
    def __init__(self) -> None:
        #instantiates a LPlayer class object
        super().__init__()
        #initialising instance variables to a specific value
        self.colour_groups = Property.COLOUR_GROUPS
        self.move_record = []

    def recurring_colour(self) -> list[str]:
        """
        Identifies the most frequently occurring colour group(s) among the AI player's properties.
        If the AI player has not purchased any property, return all the colour groups.

        Arguments:
        - None

        Returns:
        - frequent_colour_groups: List containing the most frequently occurring colour group(s) among the AI player's properties
        """
        #frequent_colour_groups: List to contain the most frequently occurring colour group(s) among the AI player's properties
        #prev_counters: List to store all previous counters used for each colour, to compare later on with the current counter
        frequent_colour_groups = []
        prev_counters = []

        for colour in self.colour_groups:
            counter = 0                                         #counter initialised to 0 for each colour in colour_groups
            for properties in self.properties_owned:            #for each property owned by the AI player
                if properties.get_colour_group() == colour:     #if the property matches the specific colour, counter will be increased by 1
                    counter += 1

            max_value = 0                                       #max_value initialised to 0 for each colour in colour_groups
            for value in prev_counters:                         #loop through all previous counter values (if any) to get the maximum value counter
                if value >= max_value:
                    max_value = value
            
            if counter == max_value:                            #if counter and max_value have the same value, append the colour to frequent_colour_groups
                frequent_colour_groups.append(colour)
            elif counter > max_value:                           #if counter > max_value, that specific colour is now the new most frequently occurring colour group
                frequent_colour_groups.clear()                  #clear the list and append the new most frequently occurring colour group to the list
                frequent_colour_groups.append(colour)
            
            prev_counters.append(counter)                       #after checking each colour, append the counter to prev_counters to compare in the next looping
            
        return frequent_colour_groups

    def round_remove(self)-> None:
        """
        Removes the first element in instance variable, move_record.

        Aruguments:
        - None

        Returns:
        - None
        """
        del self.move_record[0]     #remove first elem

    def second_criteria(self, list_coordinate: list[tuple], property_locations: dict)-> tuple:
        """
        Choose an affordable property, with the highest rent cost to purchase.

        Arguments:
        - list_coordinate: List of tuples representing valid positions
        - property_locations: Dictionary that contains all the position-property key-value pairs

        Returns:
        - most_valuable_property: Tuple representing the best position to move to
        """
        maximum = 0                                                     #set maximum to 0 
        affordable_properties = []                                      
        most_valuable_property = ""

        for coordinate in list_coordinate:                              #loop through all coordinate that AI possible landed on 
            coordinate_property = property_locations.get(coordinate)    #get location by using coordinate

                                                                        #if is affordable and no one owns that property 
            if coordinate_property.get_property_cost() != None and coordinate_property.get_property_cost() < self.get_fund() and coordinate_property.get_owner() == Property.ORIGINAL_OWNER:
                affordable_properties.append(coordinate)                #then append to affordable_properties

        if len(affordable_properties) != 0:                             #if there is affordable_properties
            for coordinate in affordable_properties:                    #then loop each properties in affordable_properties
                coordinate_property = property_locations.get(coordinate)
                                                                        #find the highest rent of the property to return
                if coordinate_property.get_rent_price() is not None:    
                    if coordinate_property.get_rent_price() > maximum:  #if the properties's rent price more than maximum
                        maximum = coordinate_property.get_rent_price()  #set maximum to that properties rent
                        most_valuable_property = coordinate             #most valuable property set to that coordinate in the loop
        else:
            most_valuable_property = random.choice(list_coordinate)     #if there is no affordable_properties
                                                                        #then randomly choose a property to land

        return most_valuable_property                                   #return most_valuable_property
        
        
    def ai_move(self, possible_moves: list[tuple], property_locations: dict) -> tuple:
        """
        Choose an appropriate move for AI 
        -Property belonging to a recurring_colour colour group that is not owned by another player,
        -highest rent and affordable
        -if first or second requirement couldn't be made then randomly choose a move 
        -cannot repeat the move within 3 rounds

        Arguments:
        - possible_moves: List of tuples representing valid positions
        - property_locations: Dictionary that contains all the position-property key-value pairs

        Returns:
        - most_valuable_move: Tuple representing the best position to move to
        """

        flag = True
        possible_land = []
        most_valuable_move = ""

        for move in possible_moves:                                 #loop through every valid move
            #find all the possible move property        
            possible_property = property_locations.get(move)        #get location based on the moves
            for colour in self.recurring_colour():                  #loop through every colour in self.recurring_colour()
                #property belongs to recurring_colour
                if colour == possible_property.get_colour_group():  #if the moves == to the colour that looping
                    #property belongs to bank
                    if possible_property.get_owner() == Property.ORIGINAL_OWNER:    #if is bank's property
                        possible_land.append(move)                  #then this move can be considere-> append to possible land

        #check for when possible_land has no elements (no property owned by bank which is of a same colour group in recurring_colour)
        #if no elements, check for diff colour property owned by bank  
        if len(possible_land) == 0:                                 #if no possible movement 
            most_valuable_move = self.second_criteria(possible_moves, property_locations) #then check second criteria

        else:            
            #check second criteria add to round record list
            most_valuable_move = self.second_criteria(possible_land, property_locations)  #if there is possible movement then check second criteria

        #loop until it returns appropriate move
        #AI Player can only revisit the same location three or more rounds later.         
        while flag == True: 
            if most_valuable_move not in self.move_record:          #if most_valuable_move not in move_record list
                if len(self.move_record) == 3:                      #then if length of the list ==3
                    self.round_remove()                             #remove last 3 round movement from that list 
                   
                self.move_record.append(most_valuable_move)         #append current round to list
                flag = False                                        #jump out of loop

                return most_valuable_move                           #return movement

            elif most_valuable_move in self.move_record:            #if most_valuable_move in move_record then 
                most_valuable_move = random.choice(possible_moves)  #randomly choose move 
                                                                    #then loop again to check that random move is it within 3 rounds movement


        
    def buy_or_build(self, best_move, property_locations: dict) -> None:
        """
        Choose an appropriate move for AI 
        decide when it is necessary to use the sell_property method, 
        decide when it is necessary to use the purchase_property method,
        decide when it is necessary to use the purchase_hotel method,
        decide when it is necessary to use the pay_rent method,
        otherwise, do nothing.

        Arguments:
        - best_move: tuples representing current location
        - property_locations: Dictionary that contains all the position-property key-value pairs

        Returns:
        - None
        """
        current_location = property_locations.get(best_move) #get current location

        #penalty
        if current_location.get_property_name() == "Penalty":   #if is penalty
            penalty_percentage = random.randint(5,30)/100       #then penalty 5 to 30 percent of the fund
            penalty_amount = round(self.get_fund() * (penalty_percentage))  
            self.reduce_fund(penalty_amount)                    #reduce AI fund
                                                                #output statement
            print("{} landed on Penalty and has been fined ${}.".format(self.get_name(), penalty_amount)) 

        #rewards
        elif current_location.get_property_name() == "Reward":  #if is rewards
            reward_amount = random.randint(30,150)              #reward between 30 to 150
            self.add_fund(reward_amount)                        #add fund
            print("{} landed on Reward and has been rewarded ${}.".format(self.get_name(), reward_amount))

        #if owner is bank then buy 
                                                                #if property of owner is bank 
        if current_location.get_property_cost() is not None and current_location.get_owner() == Property.ORIGINAL_OWNER: 
            if self.get_fund() > current_location.get_property_cost():  #if AI have sufficient fund
                self.purchase_property(current_location)                #then buy that property

        #if owner is ai then build hotel
                                                                #if is own property 
        elif current_location.get_property_cost() is not None and current_location.get_owner() == self:
            if self.get_fund() > current_location.get_hotel_cost(): #if AI have sufficient fund
                self.purchase_hotel(current_location)           #then purchase hotel for that property

        #if ai is broke(<20) then sell property
        if self.get_fund() < 20:
            if len(self.properties_owned) > 1:                  #then AI owned properties
                random_property = random.choice(self.properties_owned) #randomly choose property to sell for AI
                self.sell_property(random_property)             
                print("{} has sold {}.".format(self.get_name(), random_property))
                
        #if property owner is not bank and not self then pay rent to the owner
        if current_location.get_property_cost() is not None and current_location.get_owner() != Property.ORIGINAL_OWNER and current_location.get_owner() != self:
            self.pay_rent(current_location)                     #if step in player's property then pay rent 

        
